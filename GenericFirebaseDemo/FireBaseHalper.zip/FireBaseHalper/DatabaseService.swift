//
//  DatabaseService.swift
//  GenericFirebaseDemo
//
//  Created by Nexios Mac 4 on 08/04/24.
//

import FirebaseFirestore

public protocol DatabaseServiceProtocol {
    static func request<T>(for endPoint: EndPoint) async throws -> T where T: FirestoreCodable
    static func request<T>(for endPoint: EndPoint) async throws -> [T] where T: FirestoreCodable
    static func request(for endPoint: EndPoint) async throws
}

public class DatabaseService: DatabaseServiceProtocol {
    public static func request<T>(for endPoint: EndPoint) async throws -> T where T: FirestoreCodable {
        guard let refrance = endPoint.path as? DocumentReference else {
            throw FirestoreServiceError.documentNotFound
        }
        switch endPoint.method {
        case .get:
            guard let documentSnapshot = try? await refrance.getDocument() else {
                throw FirestoreServiceError.invalidPath
            }
            guard let documentData = documentSnapshot.data() else {
                throw FirestoreServiceError.parseError
            }
            let singleResponse: T = try Parser.parse(documentData)
            return singleResponse
        default:
            throw FirestoreServiceError.invalidRequest
        }
    }
    
    public static func request<T>(for endPoint: EndPoint) async throws -> [T] where T: FirestoreCodable {
        guard let refrance = endPoint.path as? Query else {
            throw FirestoreServiceError.collectionNotFound
        }
        switch endPoint.method {
        case .get:
            let querySnapshot = try await refrance.getDocuments()
            var response: [T] = []
            for document in querySnapshot.documents {
                let data: T = try Parser.parse(document.data())
                response.append(data)
            }
            return response
        default:
            throw FirestoreServiceError.operationNotSupported
        }
    }
    
    public static func request(for endPoint: EndPoint) async throws {
        guard let refrance = endPoint.path as? DocumentReference else {
            throw FirestoreServiceError.documentNotFound
        }
        switch endPoint.method {
        case .get:
            throw FirestoreServiceError.operationNotSupported
        case var .post(model):
            model.id = refrance.documentID
            try await refrance.setData(model.asDictionary())
        case let .update(model):
            try await refrance.setData(model.asDictionary())
        case .delete:
            try await refrance.delete()
        }
    }
}
