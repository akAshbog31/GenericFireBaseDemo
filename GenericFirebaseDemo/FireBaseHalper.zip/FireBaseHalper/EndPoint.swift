//
//  EndPoint.swift
//  GenericFirebaseDemo
//
//  Created by Nexios Mac 4 on 08/04/24.
//

import FirebaseFirestore

public protocol EndPoint {
    var path: FirestoreReference { get }
    var method: FirestoreMethod { get }
    var firestore: Firestore { get }
}

public extension EndPoint {
    var firestore: Firestore {
        Firestore.firestore()
    }
}

public enum FirestoreMethod {
    case get
    case post(any FirestoreCodable)
    case update(any FirestoreCodable)
    case delete
}

public protocol FirestoreReference {}

extension DocumentReference: FirestoreReference {}
extension Query: FirestoreReference {}

